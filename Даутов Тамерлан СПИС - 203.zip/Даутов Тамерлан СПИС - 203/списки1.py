numbers = [15, 8, 42, 4, 27, 90, 3, 56, 11, 7]
words = ["осен", "снег", "река", "код", "питон", "задача"]

print("Второй элемент первого списка:", numbers[1])

words[-1] = "финал"
print("Второй список после изменения:", words)

combined = numbers + words
print("Соединенный список:", combined)

slice_list = combined[4:15]
print("Срез после добавления символов:", slice_list)

even_numbers = []
for n in numbers:
    if n % 2 == 0:
        even_numbers.append(n)

print("Четные числа:", even_numbers)
print("Длина списка четных чисел:", len(even_numbers))

longest_index = 0
for i in range(len(words)):
    if len(words[i]) > len(words[longest_index]):
        longest_index = i

print("Индекс самого длинного слова:", longest_index)
print("Самое длинное слово:", words[longest_index])
