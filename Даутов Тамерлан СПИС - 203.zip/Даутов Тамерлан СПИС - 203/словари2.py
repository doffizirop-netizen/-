print("\n--- Задание 2 ---")

sales_lines = [
    "Иванов бумага 10",
    "Петров ручки 5",
    "Иванов маркеры 3",
    "Иванов бумага 7",
    "Петров ручки 2",
    "Сидоров конверт 1"
]

db = {}

for line in sales_lines:
    customer, item, count = line.split()
    count = int(count)

    if customer not in db:
        db[customer] = {}

    if item in db[customer]:
        db[customer][item] = db[customer][item] + count
    else:
        db[customer][item] = count

for customer in sorted(db.keys()):
    print(customer, ":")

    for item in sorted(db[customer].keys()):
        count = db[customer][item]
        print("  ", item, count)
