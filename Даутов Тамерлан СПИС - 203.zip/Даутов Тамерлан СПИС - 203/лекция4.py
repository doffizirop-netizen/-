
def square(x): return x ** 2


sq = lambda x: x ** 2
print(sq(5))  
