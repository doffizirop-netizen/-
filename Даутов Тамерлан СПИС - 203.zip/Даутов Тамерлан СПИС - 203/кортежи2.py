print("\n--- Задание 2: Удаление min/max и сортировка ---")

results = (45, 82, 12, 94, 67, 34, 88, 51)
print("Исходные результаты:", results)

max_val = max(results)
min_val = min(results)
print("Максимум для удаления:", max_val, "Минимум для удаления:", min_val)

lst = list(results)
lst.remove(max_val)
lst.remove(min_val)

lst.sort(reverse=True)

print("Результаты по убыванию после удаления:", tuple(lst))
