print("--- Задание 1 ---")
a = input("Введите числа через пробел: ").split()
s = set(a)
print("Различных чисел:", len(s))


print("\n--- Задание 2 ---")
a = input("Первый список: ").split()
b = input("Второй список: ").split()
s1 = set(a)
s2 = set(b)
common = s1 & s2
print("Одновременно в обоих списках:", len(common))


print("\n--- Задание 3 ---")
a = input("Первый список: ").split()
b = input("Второй список: ").split()
s1 = set(a)
s2 = set(b)
common = s1 & s2

numbers = []
for x in common:
    numbers.append(int(x))

numbers.sort()
print("Общие числа по возрастанию:", numbers)



print("\n--- Задание 4 ---")
a = input("Введите числа через пробел: ").split()
seen = set() 
for x in a:
    if x in seen:
        print("YES")
    else:
        print("NO")
        seen.add(x)
