import math

print("\n--- Задание 3: Комплексные числа ---")

x = 3
y = 4

mod = math.sqrt(x**2 + y**2)
arg = math.atan2(y, x)

print("Число:", x, "+", y, "i")
print("Модуль:", mod)
print("Аргумент (в радианах):", round(arg, 4))
print("Аргумент (в градусах):", round(math.degrees(arg), 1))
