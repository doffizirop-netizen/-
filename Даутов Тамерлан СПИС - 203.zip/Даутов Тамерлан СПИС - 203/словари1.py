print("--- Задание 1 ---")

countries_data = [
    "Россия Москва Петербург Новгород",
    "США НьюЙорк Вашингтон Чикаго",
    "Франция Париж Лион"
]

city_to_country = {}

for line in countries_data:
    parts = line.split()
    country = parts[0]
    cities = parts[1:]
    for city in cities:
        city_to_country[city] = country

queries = ["Москва", "Чикаго", "Париж", "Новгород"]

for city in queries:
    country = city_to_country.get(city, "Страна не найдена")
    print(city, "->", country)
