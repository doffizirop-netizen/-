var_int = 10
var_float = 5.4
var_str = "No"

big_int = var_int * 4.5
var_float = var_float - 2

print(var_int / var_float)
print(big_int / var_float)

var_str = ("No" * 2) + ("Yes" * 3)

print("var_int:", var_int)
print("big_int:", big_int)
print("var_float:", var_float)
print("var_str:", var_str)

N = 987654321

result = N % (10 ** 5) // (10 ** 2)
print("Результат выражения:", result)
