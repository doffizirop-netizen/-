print("\n--- Задание 3: Рейтинг студента ---")

student = "Олег"
hw = (6, 7, 8, 9, 5, 4)
exam = 6

total = 0
for mark in hw:
    total += mark

avg_hw = total / len(hw)
final_score = 0.4 * avg_hw + 0.6 * exam
grade = round(final_score)

print(student + ", ваш рейтинг равен", grade)
