print("--- Задание 1: Квалификация фигуристов ---")

skaters = [
    ("Иванов", 78.5),
    ("Петрова", 85.0),
    ("Сидоров", 62.1),
    ("Смирнова", 91.4),
    ("Кузнецов", 74.0),
    ("Попова", 88.3),
    ("Васильев", 69.9),
    ("Соколов", 82.6),
    ("Новикова", 55.5),
    ("Федоров", 79.0)
]

total = 0
for name, score in skaters:
    total += score

avg = total / len(skaters)
print("Средний балл всех участников:", round(avg, 2))
print()

passed = []
for name, score in skaters:
    if score > avg:
        passed.append(name)

print("Число спортсменов, прошедших квалификацию:", len(passed))
print("Фамилии прошедших участников:")
for name in passed:
    print("-", name)
