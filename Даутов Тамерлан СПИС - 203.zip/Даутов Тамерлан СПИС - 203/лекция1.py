print("--- Задание 1: Метод Крамера ---")
print("Коэффициенты системы:")
print("2*x + 1*y = 5")
print("4*x - 3*y = 5")
print()

a1, b1, c1 = 2, 1, 5
a2, b2, c2 = 4, -3, 5

d = a1 * b2 - b1 * a2
dx = c1 * b2 - b1 * c2
dy = a1 * c2 - c1 * a2

print("Главный определитель d =", d)
print("Определитель dx =", dx)
print("Определитель dy =", dy)
print()

if d != 0:
    x = dx / d
    y = dy / d
    print("Решение системы: x =", x, ", y =", y)
else:
    if dx == 0 and dy == 0:
        print("Система имеет бесконечно много решений.")
    else:
        print("Система не имеет решений.")
