import tkinter as tk

def open_settings():
    settings_win = tk.Toplevel(root)
    settings_win.title("Настройки")
    settings_win.geometry("200x150")
    settings_win.grab_set()

root = tk.Tk()
btn = tk.Button(root, text="Открыть", command=open_settings)
btn.pack(pady=50)
root.mainloop()
