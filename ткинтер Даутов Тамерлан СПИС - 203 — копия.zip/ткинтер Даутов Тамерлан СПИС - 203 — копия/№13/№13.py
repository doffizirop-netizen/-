import tkinter as tk

root = tk.Tk()
canvas = tk.Canvas(root, width=300, height=200, bg="white")
canvas.pack(pady=10)

canvas.create_line(0, 0, 300, 200, fill="red")
canvas.create_rectangle(50, 50, 150, 150, fill="blue")

root.mainloop()
