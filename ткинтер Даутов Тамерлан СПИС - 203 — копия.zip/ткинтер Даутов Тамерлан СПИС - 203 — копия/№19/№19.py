import tkinter as tk
from tkinter import ttk

root = tk.Tk()

columns = ("name", "age")
tree = ttk.Treeview(root, columns=columns, show="headings")

tree.heading("name", text="Имя")
tree.heading("age", text="Возраст")

tree.insert("", tk.END, values=("Иван", 20))

tree.pack(fill="both", expand=True)

root.mainloop()
