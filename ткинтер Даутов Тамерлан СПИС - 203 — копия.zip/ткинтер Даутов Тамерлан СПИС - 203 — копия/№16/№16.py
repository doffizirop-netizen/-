import tkinter as tk
from tkinter import ttk

root = tk.Tk()

notebook = ttk.Notebook(root)
notebook.pack(fill="both", expand=True)

tab1 = ttk.Frame(notebook)
notebook.add(tab1, text="Основное")

lbl1 = ttk.Label(tab1, text="Контент")
lbl1.pack(pady=20)

root.mainloop()
