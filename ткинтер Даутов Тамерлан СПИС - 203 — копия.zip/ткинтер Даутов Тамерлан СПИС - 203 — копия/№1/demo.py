import tkinter as tk

root = tk.Tk()
root.title("Пример")
root.geometry("400x300")

label = tk.Label(root, text="Привет, мир!")
label.pack()

root.mainloop()
