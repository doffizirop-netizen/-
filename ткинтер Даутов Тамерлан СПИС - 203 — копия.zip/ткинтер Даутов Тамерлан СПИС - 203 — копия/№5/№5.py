import tkinter as tk

def check_status():
    if is_checked.get() == 1:
        print("Активен")
    else:
        print("Пуст")

root = tk.Tk()
root.geometry("300x120")

is_checked = tk.IntVar()

agree_check = tk.Checkbutton(
    root,
    text="Согласен",
    variable=is_checked,
    command=check_status
)
agree_check.pack(pady=30)

root.mainloop()
