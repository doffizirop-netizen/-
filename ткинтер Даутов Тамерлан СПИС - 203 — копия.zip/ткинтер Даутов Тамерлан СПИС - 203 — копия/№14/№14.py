import tkinter as tk

root = tk.Tk()

main_menu = tk.Menu(root)
root.config(menu=main_menu)          # прикрепить меню к окну

file_menu = tk.Menu(main_menu, tearoff=0)
file_menu.add_command(label="Новый файл")
main_menu.add_cascade(label="Файл", menu=file_menu)

root.mainloop()
