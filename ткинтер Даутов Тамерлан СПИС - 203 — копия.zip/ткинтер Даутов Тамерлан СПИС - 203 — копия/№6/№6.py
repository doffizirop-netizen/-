import tkinter as tk

root = tk.Tk()
root.geometry("300x150")

selected_option = tk.StringVar(value="Python")

rb1 = tk.Radiobutton(root, text="Python",
                     variable=selected_option, value="Python")
rb2 = tk.Radiobutton(root, text="C++",
                     variable=selected_option, value="C++")
rb3 = tk.Radiobutton(root, text="C#",
                     variable=selected_option, value="C#")

rb1.pack(anchor="w", padx=20, pady=5)
rb2.pack(anchor="w", padx=20, pady=5)
rb3.pack(anchor="w", padx=20, pady=5)

root.mainloop()
