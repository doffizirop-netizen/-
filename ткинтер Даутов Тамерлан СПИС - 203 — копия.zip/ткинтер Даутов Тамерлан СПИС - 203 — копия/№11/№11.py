import tkinter as tk

root = tk.Tk()

top_frame = tk.Frame(root, bd=2, relief="groove", padx=10, pady=10)
top_frame.pack(pady=20)

btn1 = tk.Button(top_frame, text="Левая")
btn1.pack(side="left")

root.mainloop()
