import tkinter as tk

root = tk.Tk()
root.geometry("300x200")

my_listbox = tk.Listbox(root, selectmode="single")
my_listbox.pack(pady=10)

languages = ["Python", "C++", "Java"]
for lang in languages:
    my_listbox.insert(tk.END, lang)

root.mainloop()
