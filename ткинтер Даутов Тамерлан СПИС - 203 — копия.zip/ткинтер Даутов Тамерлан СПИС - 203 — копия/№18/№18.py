import tkinter as tk
from tkinter import ttk

root = tk.Tk()

combo = ttk.Combobox(root, values=["Москва", "Санкт-Петербург"])
combo.current(0)
combo.pack(pady=20)

root.mainloop()
