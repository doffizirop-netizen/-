import tkinter as tk

root = tk.Tk()

frame = tk.Frame(root)
frame.pack(pady=10)

scrollbar = tk.Scrollbar(frame, orient="vertical")
listbox = tk.Listbox(frame, yscrollcommand=scrollbar.set)

scrollbar.config(command=listbox.yview)
scrollbar.pack(side="right", fill="y")
listbox.pack(side="left")

for i in range(50):
    listbox.insert(tk.END, f"Строка {i+1}")

root.mainloop()
