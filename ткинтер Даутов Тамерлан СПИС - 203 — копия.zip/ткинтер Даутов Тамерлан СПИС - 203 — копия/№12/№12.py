import tkinter as tk

root = tk.Tk()

settings_group = tk.LabelFrame(root, text="Настройки звука", padx=10, pady=10)
settings_group.pack(pady=20, fill="both", expand=True, padx=15)

ch1 = tk.Checkbutton(settings_group, text="Включить эффекты")
ch1.pack(anchor="w")

root.mainloop()
