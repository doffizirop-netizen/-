import tkinter as tk

root = tk.Tk()
root.geometry("300x150")

count = 0

def increment():
    global count
    count += 1
    label.config(text=f"Нажатий: {count}")

label = tk.Label(root, text="Нажатий: 0", font=("Arial", 14))
label.pack(pady=10)

button = tk.Button(root, text="Нажми меня", command=increment)
button.pack(pady=10)

root.mainloop()
