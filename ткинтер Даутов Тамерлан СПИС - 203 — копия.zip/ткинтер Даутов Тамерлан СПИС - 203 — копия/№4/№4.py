import tkinter as tk

def show_text():
    print("Текст:", user_entry.get())

root = tk.Tk()
root.geometry("300x150")

user_entry = tk.Entry(root, width=25, font=("Arial", 12))
user_entry.pack(pady=20)

submit_btn = tk.Button(root, text="Показать", command=show_text)
submit_btn.pack()

root.mainloop()
