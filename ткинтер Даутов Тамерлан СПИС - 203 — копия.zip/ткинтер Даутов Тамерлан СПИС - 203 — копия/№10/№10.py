import tkinter as tk

root = tk.Tk()
root.geometry("300x120")

months_spin = tk.Spinbox(root,
                         values=("Сентябрь", "Октябрь", "Ноябрь"),
                         wrap=True)
months_spin.pack(pady=20)

root.mainloop()
