import tkinter as tk
from tkinter import ttk

root = tk.Tk()

progress = ttk.Progressbar(root, orient="horizontal",
                           length=200, mode="determinate")
progress.pack(pady=20)
progress["value"] += 90

root.mainloop()
