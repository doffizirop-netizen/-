import tkinter as tk

root = tk.Tk()
root.geometry("300x100")

welcome_label = tk.Label(
    root,
    text="Привет, всем!",
    font=("Helvetica", 16),
    fg="blue"
)
welcome_label.pack(pady=20)

root.mainloop()
